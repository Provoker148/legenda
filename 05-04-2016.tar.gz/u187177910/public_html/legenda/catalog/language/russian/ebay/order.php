<?php
$_['lang_shipping']     = 'Shipping';
$_['lang_discount']     = 'Discount';
$_['lang_tax']          = 'Tax';
$_['lang_subtotal']     = 'Sub-total';
$_['lang_total']        = 'Total';
