<?php
// Heading 
$_['heading_title'] = 'Корзина';

// Text
$_['text_items']    = 'Товаров:%s (%s)';
$_['text_empty']    = 'Ваша корзина пуста!';
$_['text_cart']     = 'Посмотреть корзину';
$_['text_checkout'] = 'Оформление покупки';
$_['text_payment_profile'] = 'Платежный профиль';
?>