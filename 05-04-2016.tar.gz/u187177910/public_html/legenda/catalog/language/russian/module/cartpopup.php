<?php
// Heading 
$_['heading_title']      = 'cartpopup';
$_['text_in_cart'] = 'в корзину';
$_['text_view_cart_n_checkout'] = 'Перейти в корзину';
$_['text_continue_shopping'] = 'Продолжить покупки';
$_['text_product_5'] = 'товаров добавлены';
$_['text_product_1'] = 'товар добавлен';
$_['text_product_2'] = 'товара добавлены';
// Text

?>