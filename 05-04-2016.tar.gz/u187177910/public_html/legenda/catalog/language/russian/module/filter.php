<?php
// Heading
$_['heading_title'] = 'Уточнить поисковый запрос';
?>