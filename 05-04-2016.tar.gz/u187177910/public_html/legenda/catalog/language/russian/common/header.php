<?php
// Text
$_['text_shopping_cart']  = 'Корзина';
$_['text_home']     = 'Главная';
$_['text_blog']     = 'Блог';
$_['text_wishlist'] = 'Закладки (%s)';
$_['text_compare']  = 'Сравнение товаров (%s)';
$_['text_cart']     = 'Корзина покупок';
$_['text_items']    = 'Товаров:%s (%s)';
$_['text_search']   = 'Поиск';
$_['text_welcome']  = '<a href="%s">Войти</a> или <a href="%s">зарегистрироваться</a>.';
$_['text_logged']   = 'Вы вошли как <a href="%s">%s</a> <b>(</b> <a href="%s">Выйти</a> <b>)</b>';
$_['text_account']  = 'Моя информация';
$_['text_checkout'] = 'Оформление заказа';
$_['text_language'] = 'Язык';
$_['text_currency'] = 'Валюта';
?>
