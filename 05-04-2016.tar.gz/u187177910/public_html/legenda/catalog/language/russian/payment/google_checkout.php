<?php
// Entry
$_['entry_postcode'] = 'Индекс:';
$_['entry_country']  = 'Страна:';
$_['entry_zone']     = 'Регион / Область:';
?>