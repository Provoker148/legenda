<?php
// Text
$_['text_title'] = 'Credit Card / Debit Card (Mal\'s e-commerce)';
?>