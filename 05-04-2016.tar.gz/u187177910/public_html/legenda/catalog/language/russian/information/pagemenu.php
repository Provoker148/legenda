<?php
// Text
$_['text_error'] = 'Cтраница не найдена!';
?>