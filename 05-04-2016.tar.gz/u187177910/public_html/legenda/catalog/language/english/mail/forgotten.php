<?php
// Text
$_['text_subject']  = '%s - New Password';
$_['text_greeting'] = 'A new password was requested from %s.';
$_['text_password'] = 'Your new password to is:';
?>