<?php
// Heading 
$_['heading_title'] = 'Featured';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>